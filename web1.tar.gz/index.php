<?php
session_start();

$memcached = new Memcached();
$memcached->addServer('127.0.0.1', 11211);

// Thiết lập tài khoản root và admin trong Memcached nếu chưa có
if (!$memcached->get('root_username')) {
    $memcached->set('root_username', 'root');
    $memcached->set('root_password', 'password');
}

if (!$memcached->get('admin_username')) {
    $memcached->set('admin_username', 'admin');
    $memcached->set('admin_password', 'password');
}

// Lấy thời gian hiện tại
$currentTime = time();

// Kiểm tra xem lần cuối cập nhật mật khẩu là khi nào
$lastUpdate = $memcached->get('last_password_update');

// Nếu chưa từng cập nhật hoặc đã qua 5 phút, cập nhật lại
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    if (!$lastUpdate || ($currentTime - $lastUpdate) > 300) {
        $newPassword = bin2hex(random_bytes(8));
        $memcached->set('root_password', $newPassword);
        $memcached->set('last_password_update', $currentTime);
    }
}

// Xử lý đăng nhập
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $storedUsername = $memcached->get('root_username');
    $storedPassword = $memcached->get('root_password');

    if ($username === $storedUsername && $password === $storedPassword) {
        $_SESSION['loggedin'] = true;
        header('Location: dashboard.php');
        exit();
    } else {
        $error = "Sai tài khoản hoặc mật khẩu.";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập</title>
</head>
<body>
    <h1>Đăng nhập</h1>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="POST" action="">
        <label for="username">Tài khoản:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Mật khẩu:</label>
        <input type="password" id="password" name="password" required><br><br>

        <button type="submit">Đăng nhập</button>
    </form>
</body>
</html>

